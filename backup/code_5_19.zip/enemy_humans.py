
from __future__ import division
import pygame
from units import BasicUnit, PlayerMale, EnemyMale
from npcs import SoldierNPC
from classes import Corpse, HealthPowerup
import equipment
import random
from functions import distance, obstacle, obstacle_unit

class EnemySoldier(EnemyMale):
  def __init__(self, game, name, (x,y)):
    BasicUnit.__init__(self, game, name, 'player', (x,y))
    self.name = name
    self.anim_name = "player"
    self.hostile = True
    self.playable = False
    self.ally = False
    self.has_special = False
    self.palette_swaps.update({(128,128,64): (128,128,128), (128,64,0): (128,128,128)})
    self.equipment = [
                      equipment.make(game, 'iron_chain_mail'),
                      equipment.make(game, 'iron_sword'),
                      equipment.make(game, 'iron_shield'),
                      equipment.Hairpiece(game, 'Hair', 'hairpiece'),
                      equipment.make(game, 'helm_of_suck')
                     ]
    self.inventory = []
    self.activities = ['standing', 'walking', 'attacking', 'falling', 'dead', 'stunned']
    self.current_activity = 'standing'
    self.animations = []
    self.current_hp = self.max_hp = 90
    self.min_damage = 6
    self.max_damage = 8
    self.mitigation = 0.1
    self.avoidance = 0.2
    self.evade_speed = 0.75
    self.load_animations(game, self.palette_swaps)
    self.reset(game)
    
class EnemyOfficer(EnemyMale):
  def __init__(self, game, name, (x,y)):
    BasicUnit.__init__(self, game, name, 'player', (x,y))
    self.name = name
    self.anim_name = "player"
    self.hostile = True
    self.playable = False
    self.ally = False
    self.has_special = False
    self.palette_swaps.update({(128,128,64): (192,192,192), (128,64,0): (192,192,192), (0,0,0):(64,64,64)})
    #hair
    self.equipment = [
                      equipment.make(game, 'iron_chain_mail'),
                      equipment.make(game, 'iron_sword'),
                      equipment.make(game, 'iron_shield'),
                      equipment.Hairpiece(game, 'Hair', 'hairpiece'),
                      equipment.make(game, 'officer_helm')
                     ]
    self.inventory = []
    self.activities = ['standing', 'walking', 'attacking', 'falling', 'dead', 'decapitated', 'dead_decapitated']
    self.current_activity = 'standing'
    self.animations = []
    self.max_hp = 100
    self.current_hp = self.max_hp
    self.load_animations(game, self.palette_swaps)
    self.reset(game)
    
class EnemyBandit(EnemySoldier):
  def __init__(self, game, name, (x,y)):
    t1 = pygame.time.get_ticks()
    BasicUnit.__init__(self, game, name, 'player', (x,y))
    self.vision_radius = 12
    self.hostile = True
    self.playable = False
    self.ally = False
    self.has_special = False
    self.activities = ['standing', 'walking', 'attacking', 'falling', 'dead', 'stunned']
    self.palette_swaps.update({(0,0,128):(90,60,0)})
    equip_palette_swaps =  {(128,64,0):(128,0,128), (128,128,128):(192,128,0), (192,192,192):(255,255,0)}
    self.equipment = [equipment.Sword(game, "Sword", 'sword', self.activities),
      equipment.Armor(game, "Brown Bandit Tunic", "mail", self.activities,
        {(128,128,128):(128,64,0), (0,0,0):(85,43,0)}),
      equipment.Helm(game, 'Brown Bandit Crown', 'crown', self.activities,
        {(128,128,128):(128,64,0), (0,0,0):(85,43,0), (192,192,192):(215,216,43)})]
    hairpiece = equipment.Hairpiece(game, 'Hair', 'hairpiece', self.activities)
    self.equipment.append(hairpiece)
    if random.random() <= 0.25:
      self.equipment.append(equipment.Beard(game, 'Beard', self.activities, hairpiece.palette_swaps))
    self.current_hp = self.max_hp = 80
    self.avoidance = 0
    self.mitigation = 0
    self.min_damage = 4
    self.max_damage = 7
    self.evade_speed = 0.7

    self.current_activity = 'standing'
    self.animations = []
    self.load_animations(game, self.palette_swaps)
    self.reset(game)
    t2 = pygame.time.get_ticks()
    if game.debug: print "Bandit load time:", t2-t1, "ms"

  def do_events(self, game):
    self.next_frame(game)
    #Emergency maneuvers
    for obj in game.units + game.trees:
      if obj != self:
        if (obj.x, obj.y) == (self.x, self.y):
          self.sidestep(game)
          self.reset(game)
    
    if self.current_activity == 'walking':
      if self.ticks == 2:
        self.move((self.dx, self.dy))
      elif self.ticks == 4:
        self.reset(game)
    
    elif self.current_activity == 'attacking':
      if self.ticks == 4:
        self.end_attack(game)
      elif self.ticks == 8:
        self.reset(game)
                
    elif self.current_activity == 'standing':
      if self.ticks == 4:
        self.reset(game)

    elif self.current_activity == 'falling':
      if self.ticks == 8:
        self.refresh_activity(game, 'dead')
        self.reset_ticks()
        game.corpses.append(Corpse(game, self))
        game.bandits_killed += 1
        powerup_chance = 0.30
        if random.random() < powerup_chance:
          for powerup in game.powerups:
            if (powerup.x, powerup.y) == (self.x,self.y):
              break
          else:
            game.powerups.append(HealthPowerup((self.x,self.y), 25))
        for unit in game.units:
          if unit.target_unit == self.name:
            unit.target_unit = None
        game.units.remove(self)
        return True
    
    elif self.ticks == 16:
      if self.current_activity == 'stunned':
        self.reset(game)
      
    if self.ticks == 0:
      if self.current_activity in ['falling', 'dead', 'decapitated', 'dead_decapitated', 'stunned']:
        pass
      else:
        self.get_action(game)

  def play_target_sound(self):
    filenames = ["sounds/hey.ogg"]
    filename = random.choice(filenames)
    sound = pygame.mixer.Sound(filename)
    channel = pygame.mixer.find_channel(False) #we don't want them overwriting death screams
    if channel:
      channel.play(sound)
      
class EnemyBanditVar(EnemyBandit):
  def __init__(self, game, name, (x,y)):
    t1 = pygame.time.get_ticks()
    BasicUnit.__init__(self, game, name, 'player', (x,y))
    self.vision_radius = 12
    self.hostile = True
    self.playable = False
    self.ally = False
    self.has_special = False
    self.palette_swaps.update({(0,0,128):(90,60,0)})
    self.activities = ['standing', 'walking', 'attacking', 'falling', 'dead', 'stunned']
    self.equipment = [equipment.Sword(game, "Steel Sword", "sword", self.activities,
        {(128,128,128): (189,191,193), (192,192,192): (234,229,229)}),
      equipment.Helm(game, 'Crown', 'crown', self.activities),
      equipment.Shield(game, "Green Bandit Shield", "shield2", self.activities,
        {(128,128,128):(128,128,0), (192,192,192):(170,190,90), (0,0,0):(100,140,100)}),
      equipment.Armor(game, 'Chain Mail', 'mail', self.activities)]
    hairpiece = equipment.Hairpiece(game, 'Hair', 'hairpiece', self.activities)
    self.equipment.append(hairpiece)
    if random.random() <= 0.5:
      self.equipment.append(equipment.Beard(game, 'Beard', self.activities, hairpiece.palette_swaps))
      
    self.current_hp = self.max_hp = 80
    self.avoidance = 0.3
    self.mitigation = 0
    self.min_damage = 5
    self.max_damage = 8
    self.evade_speed = 0.7
    self.current_activity = 'standing'
    self.animations = []
    self.load_animations(game, self.palette_swaps)
    self.reset(game)
    t2 = pygame.time.get_ticks()
    if game.debug:  print "Banditvar load time:", t2-t1, "ms"
    
class EnemyBanditClub(EnemyBandit):
  def __init__(self, game, name, (x,y)):
    t1 = pygame.time.get_ticks()
    BasicUnit.__init__(self, game, name, 'player', (x,y))
    self.vision_radius = 12
    self.hostile = True
    self.playable = False
    self.ally = False
    self.has_special = False
    self.palette_swaps.update({(0,0,128):(90,60,0), (128,128,64):self.skin_color, (0,0,0):self.skin_color,
                               (128,128,0):self.skin_color, (192,192,192):self.skin_color})
    self.activities = ['standing', 'walking', 'attacking_club', 'falling', 'dead', 'stunned']
    self.equipment = [equipment.Sword(game, "Club", "club", self.activities),
                      equipment.Cloak(game, 'Cloak', 'cloak', self.activities,
                        {(0,0,0):(64,64,64), (128,128,128):(128,128,64),
                        (255,0,0):(128,128,64), (255,128,64):(64,64,64)})
                     ]
    hairpiece = equipment.Hairpiece(game, 'Hair', 'hairpiece', self.activities)
    self.equipment.append(hairpiece)
    if random.random() <= 0.75:
      self.equipment.append(equipment.Beard(game, 'Beard', self.activities, hairpiece.palette_swaps))
      
    self.current_hp = self.max_hp = 100
    self.avoidance = 0
    self.mitigation = 0
    self.min_damage = 10
    self.max_damage = 16
    self.evade_speed = 0.6
    self.current_activity = 'standing'
    self.animations = []
    self.load_animations(game, self.palette_swaps)
    self.reset(game)
    t2 = pygame.time.get_ticks()
    if game.debug: print "Banditclub load time:", t2-t1, "ms"
    
  def do_events(self, game):
    self.next_frame(game)
    #Emergency maneuvers
    for obj in game.units + game.trees:
      if obj != self:
        if (obj.x, obj.y) == (self.x, self.y):
          self.sidestep(game)
          self.reset(game)
    
    if self.current_activity == 'walking':
      if self.ticks == 2:
        self.move((self.dx, self.dy))
      elif self.ticks == 4:
        self.reset(game)
    
    elif self.current_activity == 'attacking_club':
      if self.ticks == 8:
        self.end_attack(game)
      elif self.ticks == 16:
        self.reset(game)
                
    elif self.current_activity == 'standing':
      if self.ticks == 4:
        self.reset(game)

    elif self.current_activity == 'falling':
      if self.ticks == 8:
        self.refresh_activity(game, 'dead')
        self.reset_ticks()
        game.corpses.append(Corpse(game, self))
        game.bandits_killed += 1
        powerup_chance = 0.40
        if random.random() < powerup_chance:
          for powerup in game.powerups:
            if (powerup.x, powerup.y) == (self.x,self.y):
              break
          else:
            game.powerups.append(HealthPowerup((self.x,self.y), 25))
        for unit in game.units:
          if unit.target_unit == self.name:
            unit.target_unit = None
        game.units.remove(self)
        return True
    
    elif self.ticks == 16:
      if self.current_activity == 'stunned':
        self.reset(game)
      
    if self.ticks == 0:
      if self.current_activity in ['falling', 'dead', 'decapitated', 'dead_decapitated', 'stunned']:
        pass
      else:
        self.get_action(game)
        
  def get_action(self, game):
    #EnemyMale
    new_target = True
    if self.target_unit:
      target_unit = game.unit_by_name(self.target_unit)
      if not target_unit:
        self.target_unit = None
      else:
        new_target = False
  
    for unit in game.units:
      if unit.hostile != self.hostile:
        if game.LOS((self.x,self.y),(unit.x,unit.y)):
          if self.target_unit:
            target_unit = game.unit_by_name(self.target_unit)
            if distance((self.x,self.y), (unit.x,unit.y)) < distance((self.x,self.y), (target_unit.x,target_unit.y)):
              self.target_unit = unit.name
          else:
            if distance((self.x,self.y), (unit.x,unit.y)) <= 10:
              self.target_unit = unit.name
    if self.target_unit:
      unit = game.unit_by_name(self.target_unit)
      if not unit:
        self.target_unit = None
        self.reset(game)
        return False
      if new_target:
        self.play_target_sound()
      self.point_at(unit)
      if (self.current_hp / self.max_hp) <= 0.25:
        (self.dx,self.dy) = (-self.dx,-self.dy)
        if obstacle(game, (self.x+self.dx,self.y+self.dy)):
          self.sidestep(game)
        else:
          if random.random() <= self.evade_speed:
            if not obstacle(game, (self.x+self.dx,self.y+self.dy)):
              self.refresh_activity(game, 'walking')
      else: # non-critical HP      
        if obstacle(game, (self.x+self.dx, self.y+self.dy)):      
          if (unit.x, unit.y) == (self.x+self.dx, self.y+self.dy):
            self.refresh_activity(game, 'attacking_club')
          elif obstacle_unit(game, (self.x+self.dx, self.y+self.dy)):
            unit_2 = obstacle_unit(game, (self.x+self.dx, self.y+self.dy))
            if unit_2.hostile != self.hostile:
              self.target_unit = unit_2.name
              self.refresh_activity(game, 'attacking_club')  
            else:
              self.sidestep(game)
        else:
          self.refresh_activity(game, 'walking')
    else:
      if random.random() > 0.50:
        self.dx = random.randint(-1,1)
        self.dy = random.randint(-1,1)
        if not obstacle(game, (self.x+self.dx,self.y+self.dy)):
          self.refresh_activity(game, 'walking')
    self.reset_ticks()
